from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.auth import require_login
from app.models.models import (
    CashLedger, OfficeExpense, StaffAdvance, OfficeStock,
    CashReason, PaymentMode, User, Trip, DeliveryPool, DeliveryStatus
)
from app.services.day_service import get_or_create_today
from datetime import date

router = APIRouter(prefix="/office", tags=["office"])
templates = Jinja2Templates(directory="app/templates")

ALLOWED = ["OWNER", "PARTNER", "OFFICE"]


@router.get("/dashboard", response_class=HTMLResponse)
def office_dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    today = date.today()
    cash_entries = db.query(CashLedger).filter(CashLedger.erp_date == today).all()
    expenses     = db.query(OfficeExpense).filter(OfficeExpense.erp_date == today).all()
    advances     = db.query(StaffAdvance).filter(StaffAdvance.erp_date == today).all()
    trips        = db.query(Trip).filter(Trip.erp_date == today).all()
    staff        = db.query(User).filter(User.is_active == True).all()

    total_cash_in    = sum(e.amount for e in cash_entries if e.amount > 0)
    total_cash_out   = sum(e.amount for e in cash_entries if e.amount < 0)
    total_expenses   = sum(e.amount for e in expenses)
    total_deliveries = db.query(DeliveryPool).filter(
        DeliveryPool.erp_date == today,
        DeliveryPool.status.in_([DeliveryStatus.DELIVERED, DeliveryStatus.DELIVERED_EMERGENCY])
    ).count()

    return templates.TemplateResponse("office/dashboard.html", {
        "request": request,
        "user": user,
        "today": today,
        "cash_entries": cash_entries,
        "expenses": expenses,
        "advances": advances,
        "trips": trips,
        "staff": staff,
        "total_cash_in": total_cash_in,
        "total_cash_out": total_cash_out,
        "total_expenses": total_expenses,
        "total_deliveries": total_deliveries,
    })


@router.post("/opening-cash")
def opening_cash(
    request: Request,
    amount: float   = Form(...),
    notes: str      = Form(None),
    db: Session     = Depends(get_db)
):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    today = date.today()
    get_or_create_today(db, user["id"])

    # Check no existing opening cash today
    existing = db.query(CashLedger).filter(
        CashLedger.erp_date == today,
        CashLedger.reason == CashReason.OPENING
    ).first()
    if existing:
        return RedirectResponse("/office/dashboard", 302)

    entry = CashLedger(
        erp_date=today,
        location="OFFICE",
        amount=amount,
        mode=PaymentMode.CASH,
        reason=CashReason.OPENING,
        actor_id=user["id"],
        notes=notes
    )
    db.add(entry)
    db.commit()
    return RedirectResponse("/office/dashboard", 302)


@router.post("/add-expense")
def add_expense(
    request: Request,
    head:   str   = Form(...),
    amount: float = Form(...),
    mode:   str   = Form("CASH"),
    paid_to: str  = Form(None),
    notes:  str   = Form(None),
    db: Session   = Depends(get_db)
):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    today = date.today()
    expense = OfficeExpense(
        erp_date=today,
        head=head,
        amount=amount,
        mode=PaymentMode(mode),
        paid_to=paid_to,
        created_by=user["id"],
        notes=notes
    )
    db.add(expense)

    # Also record in cash ledger as outflow
    cash_out = CashLedger(
        erp_date=today,
        location="OFFICE",
        amount=-amount,
        mode=PaymentMode(mode),
        reason=CashReason.EXPENSE,
        actor_id=user["id"],
        notes=f"{head}: {notes or ''}"
    )
    db.add(cash_out)
    db.commit()
    return RedirectResponse("/office/dashboard", 302)


@router.post("/add-advance")
def add_advance(
    request: Request,
    staff_id: int  = Form(...),
    amount: float  = Form(...),
    notes: str     = Form(None),
    db: Session    = Depends(get_db)
):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    today = date.today()
    advance = StaffAdvance(
        erp_date=today,
        staff_id=staff_id,
        amount=amount,
        source="MANUAL",
        created_by=user["id"],
        notes=notes
    )
    db.add(advance)

    cash_out = CashLedger(
        erp_date=today,
        location="OFFICE",
        amount=-amount,
        mode=PaymentMode.CASH,
        reason=CashReason.ADVANCE,
        ref_id=staff_id,
        actor_id=user["id"],
        notes=notes
    )
    db.add(cash_out)
    db.commit()
    return RedirectResponse("/office/dashboard", 302)


@router.post("/sv-connection")
def sv_new_connection(
    request: Request,
    consumer_name: str = Form(...),
    consumer_no: str   = Form(None),
    amount: float      = Form(4000),
    mode: str          = Form("CASH"),
    notes: str         = Form(None),
    db: Session        = Depends(get_db)
):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    today = date.today()
    entry = CashLedger(
        erp_date=today,
        location="OFFICE",
        amount=amount,
        mode=PaymentMode(mode),
        reason=CashReason.SV_NEW_CONNECTION,
        actor_id=user["id"],
        notes=f"SV: {consumer_name} ({consumer_no or 'no no.'}). {notes or ''}"
    )
    db.add(entry)
    db.commit()
    return RedirectResponse("/office/dashboard", 302)


@router.get("/staff-ledger/{staff_id}", response_class=HTMLResponse)
def staff_ledger(staff_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ALLOWED:
        return RedirectResponse("/access-denied", 302)

    staff = db.query(User).filter(User.id == staff_id).first()
    advances = db.query(StaffAdvance).filter(StaffAdvance.staff_id == staff_id)\
                .order_by(StaffAdvance.created_at.desc()).all()
    balance = sum(a.amount for a in advances)

    return templates.TemplateResponse("office/staff_ledger.html", {
        "request": request,
        "user": user,
        "staff": staff,
        "advances": advances,
        "balance": balance,
    })
