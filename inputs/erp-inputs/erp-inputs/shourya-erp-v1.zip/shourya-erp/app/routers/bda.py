from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.auth import require_login
from app.models.models import BdaTransaction, BdaMaster, Trip, StockReason
from app.services.stock_service import add_stock_movement
from datetime import date

router = APIRouter(prefix="/bda", tags=["bda"])
templates = Jinja2Templates(directory="app/templates")


@router.get("/dashboard", response_class=HTMLResponse)
def bda_dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user
    if user["role"] not in ["OWNER", "PARTNER", "OFFICE", "DELIVERY"]:
        return RedirectResponse("/access-denied", 302)

    today    = date.today()
    bdas     = db.query(BdaMaster).filter(BdaMaster.is_active == True).all()
    txns     = db.query(BdaTransaction).filter(BdaTransaction.erp_date == today).all()

    return templates.TemplateResponse("bda/dashboard.html", {
        "request": request,
        "user": user,
        "today": today,
        "bdas": bdas,
        "txns": txns,
    })


@router.post("/transaction")
def add_bda_transaction(
    request: Request,
    bda_id:          int   = Form(...),
    trip_id:         int   = Form(None),
    filled_issued:   int   = Form(0),
    empty_received:  int   = Form(0),
    cash_paid:       float = Form(0.0),
    online_paid:     float = Form(0.0),
    cash_receiver_id: int  = Form(None),
    notes: str             = Form(None),
    db: Session            = Depends(get_db)
):
    user = require_login(request)
    if isinstance(user, RedirectResponse):
        return user

    today = date.today()
    bda   = db.query(BdaMaster).filter(BdaMaster.id == bda_id).first()
    if not bda:
        return RedirectResponse("/bda/dashboard", 302)

    txn = BdaTransaction(
        erp_date=today,
        bda_id=bda_id,
        trip_id=trip_id,
        filled_issued=filled_issued,
        empty_received=empty_received,
        cash_paid=cash_paid,
        online_paid=online_paid,
        cash_receiver_id=cash_receiver_id,
        created_by=user["id"],
        notes=notes
    )
    db.add(txn)

    # Stock movements
    bda_loc = f"BDA_{bda_id}"
    if filled_issued > 0:
        # from vehicle or godown
        source_loc = f"VEHICLE_{trip_id}" if trip_id else "GODOWN"
        add_stock_movement(db, today, "5350", source_loc, -filled_issued, True,
                           StockReason.BDA_ISSUE, "BDA", txn.id if txn.id else 0, user["id"])
        add_stock_movement(db, today, "5350", bda_loc, filled_issued, True,
                           StockReason.BDA_ISSUE, "BDA", 0, user["id"])
    if empty_received > 0:
        add_stock_movement(db, today, "5370", bda_loc, -empty_received, False,
                           StockReason.BDA_RETURN, "BDA", 0, user["id"])
        add_stock_movement(db, today, "5370", "GODOWN", empty_received, False,
                           StockReason.BDA_RETURN, "BDA", 0, user["id"])

    # Update trip BDA totals
    if trip_id:
        trip = db.query(Trip).filter(Trip.id == trip_id).first()
        if trip:
            trip.bda_cash   += cash_paid
            trip.bda_online += online_paid

    db.commit()
    return RedirectResponse("/bda/dashboard", 302)
