"""
Run ONCE on a fresh database to set up initial users, vehicles, and BDA masters.
Command: python scripts/seed_data.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import engine, SessionLocal, Base
from app.models.models import User, Vehicle, BdaMaster, UserRole
from app.core.auth import hash_pin

# Create all tables
Base.metadata.create_all(bind=engine)

db = SessionLocal()

def seed():
    # ── USERS ──────────────────────────────────────────────────────
    users = [
        {"name": "Vishal Patil",    "mobile": "9876500001", "role": UserRole.OWNER,    "pin": "1234", "rate_urban": 0, "rate_rural": 0},
        {"name": "Mrinmayi Patil",  "mobile": "9876500002", "role": UserRole.PARTNER,  "pin": "1234", "rate_urban": 0, "rate_rural": 0},
        {"name": "Bhore",           "mobile": "9876500003", "role": UserRole.DELIVERY, "pin": "1111", "rate_urban": 5, "rate_rural": 7},
        {"name": "Swapnil Patil",   "mobile": "9876500004", "role": UserRole.DELIVERY, "pin": "2222", "rate_urban": 5, "rate_rural": 7},
        {"name": "Vishal Magdum",   "mobile": "9876500005", "role": UserRole.DELIVERY, "pin": "3333", "rate_urban": 5, "rate_rural": 7},
        {"name": "Haroon",          "mobile": "9876500006", "role": UserRole.DELIVERY, "pin": "4444", "rate_urban": 5, "rate_rural": 7},
        {"name": "Sandip",          "mobile": "9876500007", "role": UserRole.LOADER,   "pin": "5555", "rate_urban": 0, "rate_rural": 0},
        {"name": "Sagar",           "mobile": "9876500008", "role": UserRole.LOADER,   "pin": "6666", "rate_urban": 0, "rate_rural": 0},
        {"name": "Ajinath",         "mobile": "9876500009", "role": UserRole.LOADER,   "pin": "7777", "rate_urban": 0, "rate_rural": 0},
        {"name": "Office Staff",    "mobile": "9876500010", "role": UserRole.OFFICE,   "pin": "8888", "rate_urban": 0, "rate_rural": 0},
    ]
    for u in users:
        existing = db.query(User).filter(User.mobile == u["mobile"]).first()
        if not existing:
            db.add(User(
                name=u["name"], mobile=u["mobile"], role=u["role"],
                pin_hash=hash_pin(u["pin"]),
                rate_urban=u["rate_urban"], rate_rural=u["rate_rural"]
            ))
    db.commit()
    print("✅ Users seeded")

    # ── VEHICLES ───────────────────────────────────────────────────
    # Get driver IDs
    bhore   = db.query(User).filter(User.name == "Bhore").first()
    swapnil = db.query(User).filter(User.name == "Swapnil Patil").first()
    magdum  = db.query(User).filter(User.name == "Vishal Magdum").first()
    haroon  = db.query(User).filter(User.name == "Haroon").first()

    vehicles = [
        {"name": "Tata 407",  "capacity": 55, "extra_cap": 10, "driver": bhore},
        {"name": "Mega XL",   "capacity": 35, "extra_cap": 8,  "driver": swapnil},
        {"name": "Hatti",     "capacity": 20, "extra_cap": 8,  "driver": magdum},
        {"name": "Appe",      "capacity": 20, "extra_cap": 8,  "driver": haroon},
        {"name": "New Hatti", "capacity": 40, "extra_cap": 5,  "driver": None},
    ]
    for v in vehicles:
        existing = db.query(Vehicle).filter(Vehicle.name == v["name"]).first()
        if not existing:
            db.add(Vehicle(
                name=v["name"], capacity=v["capacity"], extra_cap=v["extra_cap"],
                default_driver_id=v["driver"].id if v["driver"] else None
            ))
    db.commit()
    print("✅ Vehicles seeded")

    # ── BDA MASTERS ────────────────────────────────────────────────
    bdas = [
        {"name": "Shirol BDA",     "village": "Shirol",     "max_allowed": 50},
        {"name": "Kondigre BDA",   "village": "Kondigre",   "max_allowed": 30},
        {"name": "Kagal BDA",      "village": "Kagal",      "max_allowed": 30},
    ]
    for b in bdas:
        existing = db.query(BdaMaster).filter(BdaMaster.name == b["name"]).first()
        if not existing:
            db.add(BdaMaster(name=b["name"], village=b["village"], max_allowed=b["max_allowed"]))
    db.commit()
    print("✅ BDA Masters seeded")

    print("\n🎉 Seed complete!")
    print("\nLogin credentials:")
    print("  Vishal (Owner):    mobile=9876500001  PIN=1234")
    print("  Mrinmayi (Partner):mobile=9876500002  PIN=1234")
    print("  Bhore (Delivery):  mobile=9876500003  PIN=1111")
    print("  Swapnil (Delivery):mobile=9876500004  PIN=2222")
    print("  Haroon (Delivery): mobile=9876500006  PIN=4444")
    print("  Sandip (Loader):   mobile=9876500007  PIN=5555")
    print("  Office Staff:      mobile=9876500010  PIN=8888")
    print("\nChange PINs after first login!")

seed()
db.close()
