import csv

def read_bpcl_cashmemo_csv(file_path):
    deliveries = []

    with open(file_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        rows = list(reader)

    # BPCL CSV: first ~10 rows are metadata
    for row in rows[10:]:
        if len(row) < 15:
            continue

        consumer_name = row[10].strip()
        address = " ".join([
            row[11].strip(),
            row[12].strip(),
            row[13].strip(),
        ])
        mobile = row[14].strip()
        cashmemo = row[7].strip()

        if not consumer_name:
            continue

        deliveries.append({
            "name": consumer_name,
            "address": address,
            "mobile": mobile,
            "cashmemo": cashmemo,
            "status": "Pending"
        })

    return deliveries
