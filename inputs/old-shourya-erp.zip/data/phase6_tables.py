# =========================================
# Phase 6 – Layer B table initialization
# =========================================

from data.db import get_conn

def init_phase6_tables():
    conn = get_conn()
    cur = conn.cursor()

    # Godown physical stock (Page 10)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS godown_physical_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_date TEXT,
            entry_time TEXT,
            user_id INTEGER,
            filled_total INTEGER,
            empty_total INTEGER,
            raw_json TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Trip tables (Page 11)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS delivery_trips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trip_date TEXT,
            delivery_man_id INTEGER,
            vehicle_id TEXT,
            trip_no INTEGER
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS trip_cash_denomination (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trip_id INTEGER,
            d500 INTEGER,
            d200 INTEGER,
            d100 INTEGER,
            d50 INTEGER,
            d20 INTEGER,
            d10 INTEGER,
            coins INTEGER
        )
    """)

    conn.commit()
    conn.close()
