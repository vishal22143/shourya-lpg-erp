# =========================================
# Users table initialization (Testing Mode)
# =========================================

from data.db import get_conn

def init_users_table():
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            mobile TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL,
            pin TEXT NOT NULL,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Insert default users ONLY if table is empty
    cur.execute("SELECT COUNT(*) FROM users")
    count = cur.fetchone()[0]

    if count == 0:
        cur.executemany("""
            INSERT INTO users (name, mobile, role, pin)
            VALUES (?, ?, ?, ?)
        """, [
            ("Vishal Patil", "7887456789", "OWNER", "1111"),
            ("Mrinmayi Patil", "8080802880", "OWNER", "1111"),
            ("Office Manager", "8007183197", "OFFICE", "2222"),
            ("Bhore", "7643982982", "DELIVERY", "3333"),
            ("Vishal Magdum", "9096853954", "DELIVERY", "3333"),
            ("Swapnil Patil", "8830669611", "DELIVERY", "3333"),
            ("Haroon Fakir", "9970660901", "DELIVERY", "3333"),
            ("BDA Shirol", "7028502299", "BDA", "4444"),
            ("BDA Kondigre", "9561242972", "BDA", "4444")
        ])

    conn.commit()
    conn.close()
