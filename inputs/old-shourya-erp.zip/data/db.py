import sqlite3, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "delivery.db")

def get_conn():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS deliveries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cashmemo TEXT UNIQUE,
        name TEXT,
        address TEXT,
        mobile TEXT,
        status TEXT,
        otp TEXT,
        lat REAL,
        lng REAL,
        gps_captured_at DATETIME,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Safe migration if DB already exists
    for col in ("lat REAL", "lng REAL", "gps_captured_at DATETIME"):
        try:
            cur.execute(f"ALTER TABLE deliveries ADD COLUMN {col}")
        except Exception:
            pass

    conn.commit()
    conn.close()
