# =========================================
# SAP Parsed Data Tables
# =========================================

from data.db import get_conn

def init_sap_tables():
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS sap_day_end (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sap_date TEXT,
            product_code TEXT,
            closing_filled INTEGER,
            closing_empty INTEGER,
            source_pdf TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
