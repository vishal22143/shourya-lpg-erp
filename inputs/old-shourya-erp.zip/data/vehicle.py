import sqlite3, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "delivery.db")

def init_vehicle_tables():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS vehicle_trips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trip_date TEXT,
        trip_no INTEGER,
        vehicle_no TEXT,
        opening_stock INTEGER,
        issued_from_godown INTEGER,
        delivered INTEGER,
        closing_stock INTEGER,
        shortage INTEGER,
        excess INTEGER,
        bda_stock INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    conn.close()
