-- =========================================
-- Phase 6 – Layer B Database Schema
-- APPEND ONLY – SAFE TO RUN MULTIPLE TIMES
-- =========================================

CREATE TABLE IF NOT EXISTS godown_physical_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT,
    entry_time TEXT,
    user_id TEXT,
    filled_total INTEGER,
    empty_total INTEGER,
    raw_json TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS delivery_trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_date TEXT,
    delivery_man_id TEXT,
    vehicle_id TEXT,
    trip_no INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS trip_sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER,
    payment_mode TEXT,
    qty INTEGER,
    cash_part INTEGER,
    note TEXT
);

CREATE TABLE IF NOT EXISTS trip_stock_transfer (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER,
    source_type TEXT,
    source_name TEXT,
    filled_given INTEGER,
    empty_taken INTEGER
);

CREATE TABLE IF NOT EXISTS trip_cash_denomination (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER,
    d500 INTEGER,
    d200 INTEGER,
    d100 INTEGER,
    d50 INTEGER,
    d20 INTEGER,
    d10 INTEGER,
    coins INTEGER
);

CREATE TABLE IF NOT EXISTS office_opening_stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stock_date TEXT,
    product TEXT,
    filled INTEGER,
    empty INTEGER
);

CREATE TABLE IF NOT EXISTS office_additional_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT,
    item_name TEXT,
    amount INTEGER,
    cash_direction TEXT
);

CREATE TABLE IF NOT EXISTS office_expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date TEXT,
    expense_head TEXT,
    amount INTEGER,
    note TEXT
);
