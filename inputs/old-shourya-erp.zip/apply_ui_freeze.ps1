# ======================================================
# SHOURYA ERP – One-Go UI Redesign & Freeze (FIXED)
# ======================================================

$ERP_ROOT = "C:\SHOURYA_ERP"
$TEMPLATES = "$ERP_ROOT\templates"
$STATIC = "$ERP_ROOT\static"
$BACKUP = "$ERP_ROOT\ui_backup_$(Get-Date -Format yyyyMMdd_HHmmss)"

Write-Host "Creating backup at $BACKUP"
Copy-Item $TEMPLATES $BACKUP -Recurse -Force

# ---------------- CREATE STATIC CSS ----------------
New-Item -ItemType Directory -Force -Path $STATIC | Out-Null

@'
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont;
  margin: 0;
  background: #f4f6f8;
  color: #1f2937;
}
.container {
  max-width: 960px;
  margin: auto;
  padding: 16px;
}
.card {
  background: #ffffff;
  border-radius: 10px;
  padding: 16px;
  margin-bottom: 16px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}
h1,h2,h3 { margin-top: 0; }
label { font-weight: 600; margin-bottom: 6px; display: block; }
input, select {
  width: 100%;
  padding: 12px;
  font-size: 16px;
  border-radius: 8px;
  border: 1px solid #d1d5db;
  margin-bottom: 12px;
}
button {
  width: 100%;
  padding: 14px;
  font-size: 16px;
  border-radius: 10px;
  border: none;
  background: #2563eb;
  color: white;
  font-weight: 600;
}
.notice {
  background: #fff7ed;
  color: #92400e;
  padding: 12px;
  border-radius: 8px;
  font-size: 14px;
}
.status-ok { background: #dcfce7; color: #166534; padding: 8px 12px; border-radius: 8px; }
.status-diff { background: #fee2e2; color: #991b1b; padding: 8px 12px; border-radius: 8px; }
.status-pending { background: #fef3c7; color: #92400e; padding: 8px 12px; border-radius: 8px; }
'@ | Set-Content "$STATIC\app.css" -Encoding UTF8

# ---------------- CREATE BASE TEMPLATE ----------------
@'
<!DOCTYPE html>
<html lang="mr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SHOURYA ERP</title>
  <link rel="stylesheet" href="/static/app.css">
</head>
<body>
  <div class="container">
    {% block content %}{% endblock %}
  </div>
</body>
</html>
'@ | Set-Content "$TEMPLATES\base.html" -Encoding UTF8

Write-Host "UI base layout and CSS created."
Write-Host "Manual template extension can be done later if needed."
Write-Host "UI FREEZE COMPLETE"
