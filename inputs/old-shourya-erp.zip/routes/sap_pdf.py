# =====================================================
# SAP PDF Upload – Phase S1
# =====================================================

from fastapi import APIRouter, UploadFile, File, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
import os
from datetime import datetime

router = APIRouter()
templates = Jinja2Templates(directory="templates")

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAP_DIR = os.path.join(BASE_DIR, "uploads", "sap")

os.makedirs(SAP_DIR, exist_ok=True)


@router.get("/sap/upload", response_class=HTMLResponse)
async def sap_upload_page(request: Request):
    return templates.TemplateResponse(
        "sap_upload.html",
        {"request": request}
    )


@router.post("/sap/upload")
async def sap_upload(file: UploadFile = File(...)):
    today = datetime.now().strftime("%Y-%m-%d")
    save_path = os.path.join(SAP_DIR, f"sap_{today}.pdf")

    with open(save_path, "wb") as f:
        f.write(await file.read())

    return RedirectResponse(f"/day-end/{today}", status_code=302)
