# =====================================================
# SHOURYA LPG ERP
# Phase 6 – Layer B (Pages 10–13)
# STABLE VERSION (ORDER FIXED)
# =====================================================

from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from datetime import datetime
from data.db import get_conn

# ---------------- ROUTER FIRST (IMPORTANT) ----------------
router = APIRouter()
templates = Jinja2Templates(directory="templates")

# -----------------------------------------------------
# PAGE 10 – GODOWN STOCK
# -----------------------------------------------------

@router.get("/godown/physical", response_class=HTMLResponse)
async def godown_stock_page(request: Request):
    return templates.TemplateResponse(
        "godown_physical.html",
        {"request": request}
    )


@router.post("/godown/physical")
async def save_godown_stock(
    request: Request,
    filled_total: int = Form(...),
    empty_total: int = Form(...),
    raw_json: str = Form(...)
):
    user_id = request.session.get("user_id")

    conn = get_conn()
    cur = conn.cursor()

    now = datetime.now()

    cur.execute("""
        INSERT INTO godown_physical_entries
        (entry_date, entry_time, user_id, filled_total, empty_total, raw_json)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        now.strftime("%Y-%m-%d"),
        now.strftime("%H:%M:%S"),
        user_id,
        filled_total,
        empty_total,
        raw_json
    ))

    conn.commit()
    conn.close()

    return RedirectResponse("/godown/physical", status_code=303)

# -----------------------------------------------------
# PAGE 11 – TRIP DETAILS
# -----------------------------------------------------

@router.get("/trip", response_class=HTMLResponse)
async def trip_page(request: Request):
    return templates.TemplateResponse(
        "trip_entry.html",
        {"request": request}
    )

# -----------------------------------------------------
# PAGE 12 – OFFICE DAILY
# -----------------------------------------------------

@router.get("/office_daily", response_class=HTMLResponse)
async def office_daily_page(request: Request):
    return templates.TemplateResponse(
        "office_daily.html",
        {"request": request}
    )

# -----------------------------------------------------
# PAGE 13 – DAY END
# -----------------------------------------------------

@router.get("/day-end/{date}", response_class=HTMLResponse)
async def day_end_page(request: Request, date: str):
    conn = get_conn()
    cur = conn.cursor()

    # ERP Godown totals
    cur.execute("""
        SELECT COALESCE(SUM(filled_total),0)
        FROM godown_physical_entries
        WHERE entry_date = ?
    """, (date,))
    erp_filled = cur.fetchone()[0]

    # SAP totals (may be zero initially)
    cur.execute("""
        SELECT COALESCE(SUM(closing_filled),0)
        FROM sap_day_end
        WHERE sap_date = ?
    """, (date,))
    sap_filled = cur.fetchone()[0]

    diff = sap_filled - erp_filled

    if sap_filled == 0:
        sap_status = "PENDING"
    elif diff == 0:
        sap_status = "OK"
    else:
        sap_status = "DIFFERENCE"

    conn.close()

    return templates.TemplateResponse(
        "day_end.html",
        {
            "request": request,
            "date": date,
            "godown_filled": erp_filled,
            "sap_filled": sap_filled,
            "sap_diff": diff,
            "sap_status": sap_status
        }
    )
