# =========================================
# Authentication & Session (Testing Mode)
# =========================================

from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from data.db import get_conn

router = APIRouter()
templates = Jinja2Templates(directory="templates")


# ---------------- LOGIN PAGE ----------------
@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


# ---------------- LOGIN SUBMIT ----------------
@router.post("/login")
async def login_submit(
    request: Request,
    mobile: str = Form(...),
    pin: str = Form(...)
):
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        SELECT id, name, role
        FROM users
        WHERE mobile = ? AND pin = ? AND is_active = 1
    """, (mobile, pin))

    user = cur.fetchone()
    conn.close()

    if not user:
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "error": "चुकीचा मोबाईल नंबर किंवा PIN"
            }
        )

    # ---------------- SESSION ----------------
    request.session["user_id"] = user[0]
    request.session["user_name"] = user[1]
    request.session["role"] = user[2]

    role = user[2]

    # ---------------- SAFE REDIRECTS ----------------
    # (No route here can produce 404)

    if role == "DELIVERY":
        return RedirectResponse("/godown/physical", status_code=302)

    if role == "BDA":
        return RedirectResponse("/trip", status_code=302)

    if role == "OFFICE":
        return RedirectResponse("/office_daily", status_code=302)

    if role == "OWNER":
        # Temporary safe redirect for testing
        return RedirectResponse("/godown/physical", status_code=302)

    return RedirectResponse("/login", status_code=302)


# ---------------- LOGOUT ----------------
@router.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=302)
