# =====================================================
# SAP PDF Parsing & Store
# =====================================================

from fastapi import APIRouter
import pdfplumber
import os
from data.db import get_conn

router = APIRouter()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAP_DIR = os.path.join(BASE_DIR, "uploads", "sap")


@router.get("/sap/parse/{sap_date}")
async def parse_sap_pdf(sap_date: str):
    pdf_path = os.path.join(SAP_DIR, f"sap_{sap_date}.pdf")

    if not os.path.exists(pdf_path):
        return {"error": "SAP PDF not found"}

    extracted = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            lines = text.split("\n")

            for line in lines:
                # Example: 5350 14.2 KG 120 510
                if "5350" in line or "5370" in line:
                    parts = line.split()
                    nums = [p for p in parts if p.isdigit()]

                    if len(nums) >= 3:
                        extracted.append({
                            "product": nums[0],
                            "filled": int(nums[-2]),
                            "empty": int(nums[-1])
                        })

    conn = get_conn()
    cur = conn.cursor()

    for row in extracted:
        cur.execute("""
            INSERT INTO sap_day_end
            (sap_date, product_code, closing_filled, closing_empty, source_pdf)
            VALUES (?, ?, ?, ?, ?)
        """, (
            sap_date,
            row["product"],
            row["filled"],
            row["empty"],
            f"sap_{sap_date}.pdf"
        ))

    conn.commit()
    conn.close()

    return {"parsed": extracted}
