-- =========================================
-- Users table for Login & Role system
-- Testing Mode (PIN based)
-- =========================================

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    mobile TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL,        -- DELIVERY | BDA | OFFICE | OWNER
    pin TEXT NOT NULL,         -- 4-digit PIN (plain text for testing)
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
