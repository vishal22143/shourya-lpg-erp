# =====================================================
# SHOURYA LPG ERP – MAIN APPLICATION
# STABLE TESTING VERSION (NO STARTUP FAILURES)
# =====================================================

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
import os
from data.phase6_tables import init_phase6_tables
from data.sap_tables import init_sap_tables
from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory="static"), name="static")

# ---------------- BASIC APP ----------------
app = FastAPI()

# ---------------- SESSION SUPPORT ----------------
app.add_middleware(
    SessionMiddleware,
    secret_key="shourya-erp-testing"
)

# ---------------- PATHS ----------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")

templates = Jinja2Templates(directory=TEMPLATE_DIR)

# ---------------- DATABASE INIT ----------------
from data.db import init_db
from data.vehicle import init_vehicle_tables
from data.godown import init_godown_tables
from data.users import init_users_table

init_db()
init_vehicle_tables()
init_godown_tables()
init_users_table()
init_phase6_tables()
init_sap_tables()

# ---------------- HOME ----------------
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# ---------------- CORE ROUTES ----------------
from routes.auth import router as auth_router
from routes.phase6_layerB_full import router as phase6_router

app.include_router(auth_router)
app.include_router(phase6_router)

# ---------------- OPTIONAL: SAP ROUTES ----------------
# ERP must NEVER fail to start due to SAP code
try:
    from routes.sap_pdf import router as sap_router
    app.include_router(sap_router)
except Exception as e:
    print("SAP module not loaded (safe during testing):", e)
from routes.sap_parse import router as sap_parse_router
app.include_router(sap_parse_router)

# ---------------- HEALTH CHECK ----------------
@app.get("/health")
async def health():
    return {"status": "ERP running"}
